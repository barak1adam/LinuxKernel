#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/input.h>
#include <linux/init.h>
#include <linux/serio.h>
#include <linux/delay.h>
#include <linux/clk.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <mach/regs-clock.h>
#include <plat/regs-timer.h>
	 
#include <plat/regs-adc.h>
#include <mach/regs-gpio.h>
#include <linux/cdev.h>
#include <linux/miscdevice.h>

#include "s3c24xx-adc.h"

/* This excercise illustrates usage of ADC (reading from it)
 * ITS NOT FINISHED
 * please implement what needs to be done in order to activate read from the ADC
 * 1. read using the read() system call
 * 2. read using /sys file-system
 * 3. please be alert to synchronization issues
 */





////////////////////////// structs  ///////////////////////////////
typedef struct {
	wait_queue_head_t wait;
	int channel;
	int prescale;
}ADC_DEV;

////////////////////////// Globals  ///////////////////////////////
/*
 * Globals 
 */
//parameters which can be set at load time.
int major_num =   MAJOR_NUMBER;
int minor_num =   0;

static void __iomem *base_addr;

//mutex
struct mutex MY_ADC_LOCK; 

static int OwnADC = 0;
static ADC_DEV adcdev;
static volatile int ev_adc = 0;
static int adc_data;

static struct clk	*adc_clock;
struct cdev cdev;	  /* Char device structure		*/
int irq_ret=-1;

////////////////////////// defines  ///////////////////////////////
#define DEVICE_NAME	"adc"

#define ADCCON      (*(volatile unsigned long *)(base_addr + S3C2410_ADCCON))	//ADC control
#define ADCTSC      (*(volatile unsigned long *)(base_addr + S3C2410_ADCTSC))	//ADC touch screen control
#define ADCDLY      (*(volatile unsigned long *)(base_addr + S3C2410_ADCDLY))	//ADC start or Interval Delay
#define ADCDAT0     (*(volatile unsigned long *)(base_addr + S3C2410_ADCDAT0))	//ADC conversion data 0
#define ADCDAT1     (*(volatile unsigned long *)(base_addr + S3C2410_ADCDAT1))	//ADC conversion data 1
#define ADCUPDN     (*(volatile unsigned long *)(base_addr + 0x14))	//Stylus Up/Down interrupt status

#define PRESCALE_DIS        (0 << 14)
#define PRESCALE_EN         (1 << 14)
#define PRSCVL(x)           ((x) << 6)
#define ADC_INPUT(x)        ((x) << 3)
#define ADC_START           (1 << 0)
#define ADC_ENDCVT          (1 << 15)

#define START_ADC_AIN(ch, prescale) \
	do{ \
		ADCCON = PRESCALE_EN | PRSCVL(prescale) | ADC_INPUT((ch)) ; \
		ADCCON |= ADC_START; \
	}while(0)
///////////////////////////////////////////////////////////////////////////////

MODULE_AUTHOR("Benny Cohen");
MODULE_LICENSE("GPL");


////////////////////////// adcdone_int_handler  ///////////////////////////////
static irqreturn_t adcdone_int_handler(int irq, void *dev_id)
{
	if (OwnADC) {
		adc_data = ADCDAT0 & 0x3ff;

		ev_adc = 1;
		wake_up_interruptible(&adcdev.wait);
	}
	printk( KERN_WARNING  "adcdone_int_handler() INT took place\n");

	return IRQ_HANDLED;
}

////////////////////////// s3c2410_adc_read  ///////////////////////////////
static ssize_t s3c2410_adc_read(struct file *filp, char *buffer, size_t count, loff_t *ppos)
{
	char str[20];
	int value;
	size_t len;
	int r;
	printk( KERN_WARNING  "s3c2410_adc_read() started\n");
	// Do we need lock ?
	{
		printk( KERN_WARNING  "s3c2410_adc_read() mutex locked\n");
		OwnADC = 1; //we own the ADC

		START_ADC_AIN(adcdev.channel, adcdev.prescale);

		printk( KERN_WARNING  "s3c2410_adc_read() going to sleep, waiting on event\n");
		//Puts the current process to sleep on the wait queue
		wait_event_interruptible(adcdev.wait, ev_adc);
		
		printk( KERN_WARNING  "s3c2410_adc_read() just woke up from event\n");
	
		/* There some code missing here please implement it
		/* set the event for next time
		/* return ADC value to user-mode
		/* return ERROR for failure*/
	
	}
	
}
/************************************************************************************************************************/
/*
 * Open and close
 */
/************************************************************************************************************************/
////////////////////////// s3c2410_adc_open  ///////////////////////////////
static int s3c2410_adc_open(struct inode *inode, struct file *filp)
{
	printk( KERN_WARNING  "s3c2410_adc_open() started\n");
	
	//lock ?
	//do we need another IRQ request
	if(-1 ==irq_ret)
	{
		printk( KERN_WARNING  "s3c2410_adc_open() alloacting irq-request\n");
		irq_ret = request_irq(IRQ_ADC, adcdone_int_handler, IRQF_SHARED, DEVICE_NAME, &adcdev);
		if (irq_ret)
        	{
			iounmap(base_addr);
			printk( KERN_NOTICE  "Requesting IRQ for ADC failed irq_ret=%d\n",irq_ret);
			return irq_ret;
		}
	}
	
	printk( KERN_NOTICE  "s3c2410_adc_open() ADC opened\n");
	return 0;
}
////////////////////////// s3c2410_adc_release  ///////////////////////////////
static int s3c2410_adc_release(struct inode *inode, struct file *filp)
{
	printk( KERN_WARNING "s3c2410_adc_release() started\n");
	//lock ?
	if(0 ==irq_ret)
	{
		free_irq(IRQ_ADC, &adcdev);
		irq_ret=-1; //for next allocation
		printk( KERN_WARNING  "s3c2410_adc_release() irq-request de-allocated\n");
	}
	printk( KERN_WARNING "s3c2410_adc_release() adc closed\n");
	return 0;
}

////////////////////////// struct file_operations  ///////////////////////////////
static struct file_operations dev_fops = {
	owner:	THIS_MODULE,
	open:	s3c2410_adc_open,
	read:	s3c2410_adc_read,	
	release:s3c2410_adc_release,
};
/************************************************************************************************************************/
/*
 * Set up the char_dev structure for this device.
 */
static void setup_cdev(void)
{
	int err, devno = MKDEV(major_num, minor_num);
    
	cdev_init(&cdev, &dev_fops);
	cdev.owner = THIS_MODULE;
	cdev.ops = &dev_fops;
	err = cdev_add (&cdev, devno, 1);
	/* Fail gracefully if need be */
	if (err)
		printk(KERN_NOTICE "Error adding char device err=%d", err);
}
/************************************************************************************************************************/

////////////////////////// dev_init  ///////////////////////////////
static int __init dev_init(void)
{
	int result;
	dev_t dev = 0;

/*
 * Get a range of minor numbers to work with, asking for a dynamic
 * major unless directed otherwise at load time.
 */
	if (major_num) 
	{
		printk(KERN_WARNING "init_module():  major =  %d\n", major_num);
		dev = MKDEV(major_num, minor_num);
		result = register_chrdev_region(dev, 1, "ADC device");
	} 
	else 
	{
		printk(KERN_WARNING "init_module():  major =  %d\n dont have a major so ask the o.s. for one\n", major_num);
		result = alloc_chrdev_region(&dev, minor_num, 1,"ADC device");
		major_num = MAJOR(dev);
		printk(KERN_WARNING "init_module():  the o.s. gave us major =  %d\n", major_num);
	}
	
	if (result < 0) 
	{
		printk(KERN_WARNING "init_module(): REGISTRATION FAILURE %d\n", major_num);
		goto fail;  // Make this more graceful 
	}

	        
	base_addr=ioremap(S3C2410_PA_ADC,0x20);
	if (base_addr == NULL) {
		printk(KERN_ERR "Failed to remap register block\n");
		return -ENOMEM;
	}
	printk(KERN_WARNING "re-mapping register for virtual mem base_addr=%pk\n",base_addr);

	adc_clock = clk_get(NULL, "adc");
	if (!adc_clock) {
		printk(KERN_ERR "failed to get adc clock source\n");
		return -ENOENT;
	}
	// Dynamic initialization of the mutex
        // has to be inited before usage by open()
	mutex_init(&MY_ADC_LOCK);

	clk_enable(adc_clock);
	
	/* normal ADC */
	ADCTSC = 0;
	
	// init the wait_queue
	init_waitqueue_head(&(adcdev.wait));
	
	//default channel and pre-scale configuration
	adcdev.channel=0;
	adcdev.prescale=0xff;
	
	/* Initialize the char device. should be put last */
	setup_cdev();

	printk (DEVICE_NAME"\tinitialized\n");
	return 0;

 fail:
	dev_exit();
	return result;
}
////////////////////////// dev_exit  ///////////////////////////////
static void __exit dev_exit(void)
{
	dev_t devno = MKDEV(major_num, minor_num);

	iounmap(base_addr);

	if (adc_clock) {
		clk_disable(adc_clock);
		clk_put(adc_clock);
		adc_clock = NULL;
	}

	/* Get rid of our char dev entries */
	cdev_del(&cdev);
	
	/* cleanup_module is never called if registering failed */
	unregister_chrdev_region(devno, 1);
	printk(KERN_NOTICE "char device unregistered");
	printk(KERN_NOTICE "char device module unloaded");


	//misc_deregister(&misc);
}
///////////////////////////////////////////////////////////////////////////////
EXPORT_SYMBOL(MY_ADC_LOCK);
module_init(dev_init);
module_exit(dev_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("FriendlyARM Inc.");

